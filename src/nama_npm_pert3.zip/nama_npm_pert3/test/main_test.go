package test

import (
	"fmt"
	"testing"
)

func TestMain(t *testing.T) {
	t.Run("Test Pertemuan 3", func(t *testing.T) {
		fmt.Println("Pertemuan 3")
	})
}
