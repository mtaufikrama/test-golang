package keywords

func _() {
	select {
		c //@complete(" //", case)
	}
}
